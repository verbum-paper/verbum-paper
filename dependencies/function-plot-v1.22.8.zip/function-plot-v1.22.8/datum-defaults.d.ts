import { FunctionPlotDatum } from './types';
export default function datumDefaults(d: FunctionPlotDatum): FunctionPlotDatum;
