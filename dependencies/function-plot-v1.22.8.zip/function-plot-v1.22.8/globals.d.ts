declare const Globals: {
    COLORS: import("d3-color").HSLColor[];
    DEFAULT_WIDTH: number;
    DEFAULT_HEIGHT: number;
    TIP_X_EPS: number;
    DEFAULT_ITERATIONS: number;
    MAX_ITERATIONS: number;
};
export default Globals;
